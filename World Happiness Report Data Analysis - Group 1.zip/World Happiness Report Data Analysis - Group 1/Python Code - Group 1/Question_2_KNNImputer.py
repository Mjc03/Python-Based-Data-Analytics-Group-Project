import pandas as pd
import numpy as np 
from statistics import mode
from sklearn.impute import KNNImputer
from numpy import random

# Question 1 (KNN imputation)
# Victoria Torkos
# Student number: 218854448

#KNN imputer function
def imputingKNN(mat, k):
    knn = KNNImputer(n_neighbors=k)
    knn.fit(mat)
    matnew = knn.transform(mat)
    return matnew

#2015
d2015 = pd.read_csv('2015.csv')
h15 = d2015[['Happiness Score', 'Economy (GDP per Capita)', 'Family', 'Health (Life Expectancy)']]
l15 = d2015[['Happiness Score', 'Freedom','Trust (Government Corruption)','Generosity']]
#2016
d2016 = pd.read_csv('2016.csv')
h16 = d2016[['Happiness Score', 'Economy (GDP per Capita)', 'Family', 'Health (Life Expectancy)']]
l16 = d2016[['Happiness Score', 'Freedom','Trust (Government Corruption)','Generosity']]
#2017
d2017 = pd.read_csv('2017.csv')
h17 = d2017[["Happiness.Score","Economy..GDP.per.Capita.","Family","Health..Life.Expectancy."]]
l17 = d2017[["Happiness.Score","Freedom","Generosity","Trust..Government.Corruption."]]
#2018
d2018 = pd.read_csv('2018.csv')
h18 = d2018[['Score','GDP per capita','Social support','Healthy life expectancy']]
l18 = d2018[['Score','Freedom to make life choices','Generosity','Perceptions of corruption']]
#2019
d2019 = pd.read_csv('2019.csv')
h19 = d2019[['Score','GDP per capita','Social support','Healthy life expectancy']]
l19 = d2019[['Score','Freedom to make life choices','Generosity','Perceptions of corruption']]

#============================================
# HIGH vs LOW correlation compare (RANDOM)
#============================================
# example is here for 2015 but can be run for 2016 and other sets if modifed
val = random.randint(159)

actual = h15.loc[val,'Happiness Score' ]
h15.loc[val,'Happiness Score' ] = np.nan
l15.loc[val,'Happiness Score' ] = np.nan

print("========================")
print("2015 Actual Happiness Score:")
print("========================")
print(d2015.loc[val, 'Country'])
print(actual)
print("========================")
print("Highest correlating attributes imputation result:")
print("========================")
imputedh = imputingKNN(h15, 3)
print(f"K = 3: {imputedh[val,0]}" )
print(f"Distance:  {abs(imputedh[val,0]-actual)}" )

print("========================")
print("Lowest correlating attributes imputation result:")
print("========================")
imputedl = imputingKNN(l15, 3)
print(f"K = 3: {imputedl[val,0]}" )
print(f"Distance:  {abs(imputedl[val,0]-actual)}" )

#============================================
# This counter can be used for 2015 and 2016 (just change the values for 2016)
# Counts the times when highest attributes imputation is closer to real Happiness score
# Counts the times when lowest attributes imputation is closer to real Happiness score
#============================================
"""
#the country for NAN
#val = random.randint(159)
val = 0
pointh = 0
pointl = 0
same = 0
for i in range(157):

    actual = h15.loc[val,'Happiness Score' ]

    h15.loc[val,'Happiness Score' ] = np.nan
    l15.loc[val,'Happiness Score' ] = np.nan

    imputedh = imputingKNN(h15, 3)
    disth = abs(imputedh[val,0]-actual)

    imputedl = imputingKNN(l15, 3)
    distl = abs(imputedl[val,0]-actual)

    if distl > disth:
        pointh = pointh + 1
    elif disth > distl:
        pointl = pointl + 1
    elif distl == disth:
        same = same + 1

    val = val + 1

print(pointh)
print(pointl)
print(same)

"""
#============================================
# This counter can be used for 2017, 2018, 2019 (just change the values for each country)
# Counts the times when highest attributes imputation is closer to real Happiness score
# Counts the times when lowest attributes imputation is closer to real Happiness score
#============================================
"""
val = 0
pointh = 0
pointl = 0
same = 0
for i in range(156):

    actual = h17.loc[val,'Score' ]

    h17.loc[val,'Score' ] = np.nan
    l17.loc[val,'Score' ] = np.nan

    imputedh = imputingKNN(h17, 3)
    disth = abs(imputedh[val,0]-actual)

    imputedl = imputingKNN(l17, 3)
    distl = abs(imputedl[val,0]-actual)

    if distl > disth:
        pointh = pointh + 1
    elif disth > distl:
        pointl = pointl + 1
    elif distl == disth:
        same = same + 1

    val = val + 1
print(pointh)
print(pointl)
print(same)
"""