import pandas as pd
import numpy as np 
from scipy.spatial import distance_matrix
import math

# Question 1 (means and distance)
# Victoria Torkos
# Student number: 218854448

#============================================
# PEARSON CORRELATION FUNCTION
#============================================
def PearsonCorrelation(x, y): 
    count = 0
    xmean = np.mean(x)
    ymean = np.mean(y)
    numeratorsum = 0
    denomxsum = 0
    denomysum = 0
    for i in range(len(x)):
        numerator = (x[count]-xmean)*(y[count]-ymean)
        numeratorsum = numerator + numeratorsum
        denomx = (x[count]-xmean)**2
        denomxsum = denomx + denomxsum
        denomy = (y[count]-ymean)**2
        denomysum = denomy + denomysum
        count = count + 1
    denominator = denomxsum*denomysum
    denominator = math.sqrt(denominator)
    r = numeratorsum/denominator
    return r

#============================================
# MEANS OF EACH ATTRIBUTE FOR EACH DATASET (SPECIFIED) FUNCTION
#============================================
def means(dataset, x):
# the new order is now: gdp, fam, health, free, trust, gen
    if x == 15 or x == 16:
        #hscore = np.average(dataset.iloc[:,1].to_numpy())
        gdp = np.average(dataset.iloc[:,2].to_numpy())
        fam = np.average(dataset.iloc[:,3].to_numpy())
        health = np.average(dataset.iloc[:,4].to_numpy())
        free = np.average(dataset.iloc[:,5].to_numpy())
        trust = np.average(dataset.iloc[:,6].to_numpy())
        gen = np.average(dataset.iloc[:,7].to_numpy())
        means = np.array([gdp, fam, health, free, trust, gen])
        return means

    elif x >= 17 and x <=19:
         #hscore = np.average(dataset.iloc[:,1].to_numpy())
         gdp = np.average(dataset.iloc[:,2].to_numpy())
         fam = np.average(dataset.iloc[:,3].to_numpy())
         health = np.average(dataset.iloc[:,4].to_numpy())
         free = np.average(dataset.iloc[:,5].to_numpy())
         gen = np.average(dataset.iloc[:,6].to_numpy())
         trust = np.average(dataset.iloc[:,7].to_numpy())
         means = np.array([gdp, fam, health, free, trust, gen])
         return means
    
    elif x == 0:
        gdp = np.average(dataset[:,0])
        fam = np.average(dataset[:,1])
        health = np.average(dataset[:,2])
        free = np.average(dataset[:,3])
        trust = np.average(dataset[:,4])
        gen = np.average(dataset[:,5])
        means = np.array([gdp, fam, health, free, trust, gen])
        return means

       

#years
d2015 = pd.read_csv('2015.csv')
d2015 = d2015[['Country', 'Happiness Score', 'Economy (GDP per Capita)','Family','Health (Life Expectancy)','Freedom','Trust (Government Corruption)','Generosity']]

d2016 = pd.read_csv('2016.csv')
d2016 = d2016[['Country', 'Happiness Score', 'Economy (GDP per Capita)','Family','Health (Life Expectancy)','Freedom','Trust (Government Corruption)','Generosity']]

d2017 = pd.read_csv('2017.csv')
d2017 = d2017[['Country','Happiness.Score','Economy..GDP.per.Capita.','Family','Health..Life.Expectancy.','Freedom','Generosity','Trust..Government.Corruption.']]

d2018 = pd.read_csv('2018.csv')
d2018 = d2018[['Country or region','Score','GDP per capita','Social support','Healthy life expectancy','Freedom to make life choices','Generosity','Perceptions of corruption']]

d2019 = pd.read_csv('2019.csv')
d2019 = d2019[['Country or region','Score','GDP per capita','Social support','Healthy life expectancy','Freedom to make life choices','Generosity','Perceptions of corruption']]

print("=========================================================")
print("MEANS FOR EACH ATTRIBUTE:")
print("ORDER: gdp, family, health, freedom, trust in government, generosity")
print("=========================================================")
#calculating the means of the 6 attributes
means15 = means(d2015,15)
print("2015")
print(means15)
means16 = means(d2016,16)
print("2016")
print(means16)
means17 = means(d2017,17)
print("2017")
print(means17)
means18 = means(d2018,18)
print("2018")
#there is an NAN value so it needs to be removed so the means can be calculated
trust18 = d2018.iloc[:,7].to_numpy()
nonan = trust18[~np.isnan(trust18)]
trust18 = np.average(nonan)
means18[4] = trust18

print(means18)
means19 = means(d2019,19)
print("2019")
print(means19)


#calculating the means of the means
print("=========================================================")
print("MEANS OF THE MEANS FOR EACH ATTRIBUTE :")
print("=========================================================")
meansall = np.array([means15, means16, means17, means18, means19])
meansall = means(meansall,0)
print(meansall)


# Calculating distance matrix of the average observations of each year
print("=========================================================")
print("DISTANCE MATRIX:")
print("=========================================================")
meansmat = np.array([means15,means16,means17,means18,means19])
print(distance_matrix(meansmat, meansmat,  p=float('inf')))


#============================================
 # Correlation: Pearson
#============================================
print("====================================")
print("Correlation using Pearson Equation")
print("====================================")
print("GDP and Happiness Score:")
print("2015 - " + str(PearsonCorrelation(d2015.iloc[:,2].to_numpy(), d2015.iloc[:,1].to_numpy())))
print("2016 - " + str(PearsonCorrelation(d2016.iloc[:,2].to_numpy(), d2016.iloc[:,1].to_numpy())))
print("2017 - " + str(PearsonCorrelation(d2017.iloc[:,2].to_numpy(), d2017.iloc[:,1].to_numpy())))
print("2018 - " + str(PearsonCorrelation(d2018.iloc[:,2].to_numpy(), d2018.iloc[:,1].to_numpy())))
print("2019 - " + str(PearsonCorrelation(d2019.iloc[:,2].to_numpy(), d2019.iloc[:,1].to_numpy())))
print("--------------------------")
print("Family and Happiness Score:")
print("2015 - " + str(PearsonCorrelation(d2015.iloc[:,3].to_numpy(), d2015.iloc[:,1].to_numpy())))
print("2016 - " + str(PearsonCorrelation(d2016.iloc[:,3].to_numpy(), d2016.iloc[:,1].to_numpy())))
print("2017 - " + str(PearsonCorrelation(d2017.iloc[:,3].to_numpy(), d2017.iloc[:,1].to_numpy())))
print("2018 - " + str(PearsonCorrelation(d2018.iloc[:,3].to_numpy(), d2018.iloc[:,1].to_numpy())))
print("2019 - " + str(PearsonCorrelation(d2019.iloc[:,3].to_numpy(), d2019.iloc[:,1].to_numpy())))
print("--------------------------")
print("Health (Life expectancy) and Happiness Score:")
print("2015 - " + str(PearsonCorrelation(d2015.iloc[:,4].to_numpy(), d2015.iloc[:,1].to_numpy())))
print("2016 - " + str(PearsonCorrelation(d2016.iloc[:,4].to_numpy(), d2016.iloc[:,1].to_numpy())))
print("2017 - " + str(PearsonCorrelation(d2017.iloc[:,4].to_numpy(), d2017.iloc[:,1].to_numpy())))
print("2018 - " + str(PearsonCorrelation(d2018.iloc[:,4].to_numpy(), d2018.iloc[:,1].to_numpy())))
print("2019 - " + str(PearsonCorrelation(d2019.iloc[:,4].to_numpy(), d2019.iloc[:,1].to_numpy())))
print("--------------------------")
print("Freedom and Happiness Score:")
print("2015 - " + str(PearsonCorrelation(d2015.iloc[:,5].to_numpy(), d2015.iloc[:,1].to_numpy())))
print("2016 - " + str(PearsonCorrelation(d2016.iloc[:,5].to_numpy(), d2016.iloc[:,1].to_numpy())))
print("2017 - " + str(PearsonCorrelation(d2017.iloc[:,5].to_numpy(), d2017.iloc[:,1].to_numpy())))
print("2018 - " + str(PearsonCorrelation(d2018.iloc[:,5].to_numpy(), d2018.iloc[:,1].to_numpy())))
print("2019 - " + str(PearsonCorrelation(d2019.iloc[:,5].to_numpy(), d2019.iloc[:,1].to_numpy())))
print("--------------------------")
print("Trust (Government Corruption) and Happiness Score:")
print("2015 - " + str(PearsonCorrelation(d2015.iloc[:,6].to_numpy(), d2015.iloc[:,1].to_numpy())))
print("2016 - " + str(PearsonCorrelation(d2016.iloc[:,6].to_numpy(), d2016.iloc[:,1].to_numpy())))
print("2017 - " + str(PearsonCorrelation(d2017.iloc[:,6].to_numpy(), d2017.iloc[:,1].to_numpy())))
print("2018 - " + str(PearsonCorrelation(nonan, d2018.iloc[:,1].to_numpy())))
print("2019 - " + str(PearsonCorrelation(d2019.iloc[:,7].to_numpy(), d2019.iloc[:,1].to_numpy())))
print("--------------------------")
print("Generosity and Happiness Score:")
print("2015 - " + str(PearsonCorrelation(d2015.iloc[:,7].to_numpy(), d2015.iloc[:,1].to_numpy())))
print("2016 - " + str(PearsonCorrelation(d2016.iloc[:,7].to_numpy(), d2016.iloc[:,1].to_numpy())))
print("2017 - " + str(PearsonCorrelation(d2017.iloc[:,7].to_numpy(), d2017.iloc[:,1].to_numpy())))
print("2018 - " + str(PearsonCorrelation(d2018.iloc[:,6].to_numpy(), d2018.iloc[:,1].to_numpy())))
print("2019 - " + str(PearsonCorrelation(d2019.iloc[:,6].to_numpy(), d2019.iloc[:,1].to_numpy())))
print("--------------------------")